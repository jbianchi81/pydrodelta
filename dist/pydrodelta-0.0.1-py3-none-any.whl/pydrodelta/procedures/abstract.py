from ..procedure_function import ProcedureFunction

class AbstractProcedureFunction(ProcedureFunction):
    """Abstract procedure function"""