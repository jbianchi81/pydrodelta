from typing import TypedDict 

class AdjustFromDict(TypedDict):
    """
        truth: int
        sim: int
    """
    truth: int
    sim: int
