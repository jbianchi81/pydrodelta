from typing import TypedDict

class SaveVariableSimDict(TypedDict):
    var_id : int
    output : str
