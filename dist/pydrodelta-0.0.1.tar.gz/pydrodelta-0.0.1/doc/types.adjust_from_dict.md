# Table of Contents

* [pydrodelta.types.adjust\_from\_dict](#pydrodelta.types.adjust_from_dict)
  * [AdjustFromDict](#pydrodelta.types.adjust_from_dict.AdjustFromDict)

<a id="pydrodelta.types.adjust_from_dict"></a>

# pydrodelta.types.adjust\_from\_dict

<a id="pydrodelta.types.adjust_from_dict.AdjustFromDict"></a>

## AdjustFromDict Objects

```python
class AdjustFromDict(TypedDict)
```

truth: int
sim: int

