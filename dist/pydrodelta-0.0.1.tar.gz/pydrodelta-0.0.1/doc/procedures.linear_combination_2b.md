# Table of Contents

* [pydrodelta.procedures.linear\_combination\_2b](#pydrodelta.procedures.linear_combination_2b)
  * [LinearCombination2BProcedureFunction](#pydrodelta.procedures.linear_combination_2b.LinearCombination2BProcedureFunction)

<a id="pydrodelta.procedures.linear_combination_2b"></a>

# pydrodelta.procedures.linear\_combination\_2b

<a id="pydrodelta.procedures.linear_combination_2b.LinearCombination2BProcedureFunction"></a>

## LinearCombination2BProcedureFunction Objects

```python
class LinearCombination2BProcedureFunction(LinearCombinationProcedureFunction)
```

Linear combination procedure with 2 inputs

