# Table of Contents

* [pydrodelta.function\_boundary](#pydrodelta.function_boundary)
  * [FunctionBoundary](#pydrodelta.function_boundary.FunctionBoundary)

<a id="pydrodelta.function_boundary"></a>

# pydrodelta.function\_boundary

<a id="pydrodelta.function_boundary.FunctionBoundary"></a>

## FunctionBoundary Objects

```python
class FunctionBoundary()
```

A boundary condition definition for a procedure function class

