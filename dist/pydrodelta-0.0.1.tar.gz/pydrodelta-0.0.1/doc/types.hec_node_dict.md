# Table of Contents

* [pydrodelta.types.hec\_node\_dict](#pydrodelta.types.hec_node_dict)
  * [HecNodeDict](#pydrodelta.types.hec_node_dict.HecNodeDict)

<a id="pydrodelta.types.hec_node_dict"></a>

# pydrodelta.types.hec\_node\_dict

<a id="pydrodelta.types.hec_node_dict.HecNodeDict"></a>

## HecNodeDict Objects

```python
class HecNodeDict(TypedDict)
```

River  : str
Reach : str
River_Stat : int
Interval : str
CondBorde: str

