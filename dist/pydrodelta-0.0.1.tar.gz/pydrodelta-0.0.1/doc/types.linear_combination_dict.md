# Table of Contents

* [pydrodelta.types.linear\_combination\_dict](#pydrodelta.types.linear_combination_dict)
  * [LinearCombinationDict](#pydrodelta.types.linear_combination_dict.LinearCombinationDict)

<a id="pydrodelta.types.linear_combination_dict"></a>

# pydrodelta.types.linear\_combination\_dict

<a id="pydrodelta.types.linear_combination_dict.LinearCombinationDict"></a>

## LinearCombinationDict Objects

```python
class LinearCombinationDict(TypedDict)
```

coefficients: List[float]
intercept: float

