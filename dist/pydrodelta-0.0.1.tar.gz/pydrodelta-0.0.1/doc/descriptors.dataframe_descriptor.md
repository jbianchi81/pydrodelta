# Table of Contents

* [pydrodelta.descriptors.dataframe\_descriptor](#pydrodelta.descriptors.dataframe_descriptor)
  * [DataFrameDescriptor](#pydrodelta.descriptors.dataframe_descriptor.DataFrameDescriptor)

<a id="pydrodelta.descriptors.dataframe_descriptor"></a>

# pydrodelta.descriptors.dataframe\_descriptor

<a id="pydrodelta.descriptors.dataframe_descriptor.DataFrameDescriptor"></a>

## DataFrameDescriptor Objects

```python
class DataFrameDescriptor()
```

DataFrame descriptor with default None

