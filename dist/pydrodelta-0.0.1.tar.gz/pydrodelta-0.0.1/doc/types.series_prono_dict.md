# Table of Contents

* [pydrodelta.types.series\_prono\_dict](#pydrodelta.types.series_prono_dict)
  * [SeriesPronoDict](#pydrodelta.types.series_prono_dict.SeriesPronoDict)

<a id="pydrodelta.types.series_prono_dict"></a>

# pydrodelta.types.series\_prono\_dict

<a id="pydrodelta.types.series_prono_dict.SeriesPronoDict"></a>

## SeriesPronoDict Objects

```python
class SeriesPronoDict(TypedDict)
```

**Arguments**:

  -----------
  series_id : int
  
  series_table : str
  
- `pronosticos` - List[TVP]

