# Table of Contents

* [pydrodelta.descriptors.bool\_descriptor](#pydrodelta.descriptors.bool_descriptor)
  * [BoolDescriptor](#pydrodelta.descriptors.bool_descriptor.BoolDescriptor)

<a id="pydrodelta.descriptors.bool_descriptor"></a>

# pydrodelta.descriptors.bool\_descriptor

<a id="pydrodelta.descriptors.bool_descriptor.BoolDescriptor"></a>

## BoolDescriptor Objects

```python
class BoolDescriptor()
```

Boolean attribute default False

