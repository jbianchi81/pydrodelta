# Table of Contents

* [pydrodelta.types.observed\_node\_variable\_dict](#pydrodelta.types.observed_node_variable_dict)
  * [ObservedNodeVariableDict](#pydrodelta.types.observed_node_variable_dict.ObservedNodeVariableDict)

<a id="pydrodelta.types.observed_node_variable_dict"></a>

# pydrodelta.types.observed\_node\_variable\_dict

<a id="pydrodelta.types.observed_node_variable_dict.ObservedNodeVariableDict"></a>

## ObservedNodeVariableDict Objects

```python
class ObservedNodeVariableDict(NodeVariableDict)
```

series : List[Union[SeriesDict,NodeSerie]]
series_prono : List[Union[SeriesPronoDict,NodeSerieProno]]

