# Table of Contents

* [pydrodelta.descriptors.list\_or\_dict\_descriptor](#pydrodelta.descriptors.list_or_dict_descriptor)
  * [ListOrDictDescriptor](#pydrodelta.descriptors.list_or_dict_descriptor.ListOrDictDescriptor)

<a id="pydrodelta.descriptors.list_or_dict_descriptor"></a>

# pydrodelta.descriptors.list\_or\_dict\_descriptor

<a id="pydrodelta.descriptors.list_or_dict_descriptor.ListOrDictDescriptor"></a>

## ListOrDictDescriptor Objects

```python
class ListOrDictDescriptor()
```

List or dict descriptor with default None

