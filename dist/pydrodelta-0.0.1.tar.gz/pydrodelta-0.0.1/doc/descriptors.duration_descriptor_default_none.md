# Table of Contents

* [pydrodelta.descriptors.duration\_descriptor\_default\_none](#pydrodelta.descriptors.duration_descriptor_default_none)
  * [DurationDescriptorDefaultNone](#pydrodelta.descriptors.duration_descriptor_default_none.DurationDescriptorDefaultNone)

<a id="pydrodelta.descriptors.duration_descriptor_default_none"></a>

# pydrodelta.descriptors.duration\_descriptor\_default\_none

<a id="pydrodelta.descriptors.duration_descriptor_default_none.DurationDescriptorDefaultNone"></a>

## DurationDescriptorDefaultNone Objects

```python
class DurationDescriptorDefaultNone(DurationDescriptor)
```

Duration descriptor
Parses dict of unit: value pairs (i.e., {"hours":1,"minutes":30})

Return type: datetime.timedelta. 

Default: None(hours=0)

