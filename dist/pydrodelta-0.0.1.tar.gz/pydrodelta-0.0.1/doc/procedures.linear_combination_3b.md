# Table of Contents

* [pydrodelta.procedures.linear\_combination\_3b](#pydrodelta.procedures.linear_combination_3b)
  * [LinearCombination3BProcedureFunction](#pydrodelta.procedures.linear_combination_3b.LinearCombination3BProcedureFunction)

<a id="pydrodelta.procedures.linear_combination_3b"></a>

# pydrodelta.procedures.linear\_combination\_3b

<a id="pydrodelta.procedures.linear_combination_3b.LinearCombination3BProcedureFunction"></a>

## LinearCombination3BProcedureFunction Objects

```python
class LinearCombination3BProcedureFunction(LinearCombinationProcedureFunction)
```

Linear combination procedure with 3 inputs

