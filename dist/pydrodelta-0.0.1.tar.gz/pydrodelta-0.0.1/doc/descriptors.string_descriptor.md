# Table of Contents

* [pydrodelta.descriptors.string\_descriptor](#pydrodelta.descriptors.string_descriptor)
  * [StringDescriptor](#pydrodelta.descriptors.string_descriptor.StringDescriptor)
    * [\_\_set\_name\_\_](#pydrodelta.descriptors.string_descriptor.StringDescriptor.__set_name__)

<a id="pydrodelta.descriptors.string_descriptor"></a>

# pydrodelta.descriptors.string\_descriptor

<a id="pydrodelta.descriptors.string_descriptor.StringDescriptor"></a>

## StringDescriptor Objects

```python
class StringDescriptor()
```

<a id="pydrodelta.descriptors.string_descriptor.StringDescriptor.__set_name__"></a>

#### \_\_set\_name\_\_

```python
def __set_name__(owner, name)
```

A string descriptor with default None

