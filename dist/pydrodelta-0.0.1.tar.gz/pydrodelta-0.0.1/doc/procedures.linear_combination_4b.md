# Table of Contents

* [pydrodelta.procedures.linear\_combination\_4b](#pydrodelta.procedures.linear_combination_4b)
  * [LinearCombination4BProcedureFunction](#pydrodelta.procedures.linear_combination_4b.LinearCombination4BProcedureFunction)

<a id="pydrodelta.procedures.linear_combination_4b"></a>

# pydrodelta.procedures.linear\_combination\_4b

<a id="pydrodelta.procedures.linear_combination_4b.LinearCombination4BProcedureFunction"></a>

## LinearCombination4BProcedureFunction Objects

```python
class LinearCombination4BProcedureFunction(LinearCombinationProcedureFunction)
```

Linear combination procedure with 4 inputs

