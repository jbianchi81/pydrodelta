# Table of Contents

* [pydrodelta.types.tvp](#pydrodelta.types.tvp)
  * [TVP](#pydrodelta.types.tvp.TVP)

<a id="pydrodelta.types.tvp"></a>

# pydrodelta.types.tvp

<a id="pydrodelta.types.tvp.TVP"></a>

## TVP Objects

```python
class TVP(TypedDict)
```

**Arguments**:

  -----------
  timestart : datetime
  
  valor : float
  
  series_id : int = None

