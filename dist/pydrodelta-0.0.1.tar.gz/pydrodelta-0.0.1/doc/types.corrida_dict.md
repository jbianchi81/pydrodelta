# Table of Contents

* [pydrodelta.types.corrida\_dict](#pydrodelta.types.corrida_dict)
  * [CorridaDict](#pydrodelta.types.corrida_dict.CorridaDict)

<a id="pydrodelta.types.corrida_dict"></a>

# pydrodelta.types.corrida\_dict

<a id="pydrodelta.types.corrida_dict.CorridaDict"></a>

## CorridaDict Objects

```python
class CorridaDict(TypedDict)
```

**Arguments**:

  -----------
  cal_id : int
  
  id : int
  
  forecast_date : datetime
  
- `series` - List[SeriesPronoDict]

