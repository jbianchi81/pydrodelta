# Table of Contents

* [pydrodelta.descriptors.int\_descriptor](#pydrodelta.descriptors.int_descriptor)

<a id="pydrodelta.descriptors.int_descriptor"></a>

# pydrodelta.descriptors.int\_descriptor

