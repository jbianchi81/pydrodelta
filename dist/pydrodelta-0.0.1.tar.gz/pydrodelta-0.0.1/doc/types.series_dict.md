# Table of Contents

* [pydrodelta.types.series\_dict](#pydrodelta.types.series_dict)
  * [SeriesDict](#pydrodelta.types.series_dict.SeriesDict)

<a id="pydrodelta.types.series_dict"></a>

# pydrodelta.types.series\_dict

<a id="pydrodelta.types.series_dict.SeriesDict"></a>

## SeriesDict Objects

```python
class SeriesDict(TypedDict)
```

**Arguments**:

  -----------
  series_id : int
  
  series_table : str
  
- `observaciones` - List[TVP]

