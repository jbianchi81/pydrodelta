# Table of Contents

* [pydrodelta.descriptors.bool\_or\_none\_descriptor](#pydrodelta.descriptors.bool_or_none_descriptor)
  * [BoolOrNoneDescriptor](#pydrodelta.descriptors.bool_or_none_descriptor.BoolOrNoneDescriptor)

<a id="pydrodelta.descriptors.bool_or_none_descriptor"></a>

# pydrodelta.descriptors.bool\_or\_none\_descriptor

<a id="pydrodelta.descriptors.bool_or_none_descriptor.BoolOrNoneDescriptor"></a>

## BoolOrNoneDescriptor Objects

```python
class BoolOrNoneDescriptor()
```

Boolean or None attribute default None

