# Table of Contents

* [pydrodelta.descriptors.float\_descriptor](#pydrodelta.descriptors.float_descriptor)
  * [FloatDescriptor](#pydrodelta.descriptors.float_descriptor.FloatDescriptor)

<a id="pydrodelta.descriptors.float_descriptor"></a>

# pydrodelta.descriptors.float\_descriptor

<a id="pydrodelta.descriptors.float_descriptor.FloatDescriptor"></a>

## FloatDescriptor Objects

```python
class FloatDescriptor()
```

A float descriptor with default None

