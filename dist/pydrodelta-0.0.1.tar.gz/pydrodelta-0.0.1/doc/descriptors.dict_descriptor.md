# Table of Contents

* [pydrodelta.descriptors.dict\_descriptor](#pydrodelta.descriptors.dict_descriptor)
  * [DictDescriptor](#pydrodelta.descriptors.dict_descriptor.DictDescriptor)

<a id="pydrodelta.descriptors.dict_descriptor"></a>

# pydrodelta.descriptors.dict\_descriptor

<a id="pydrodelta.descriptors.dict_descriptor.DictDescriptor"></a>

## DictDescriptor Objects

```python
class DictDescriptor()
```

Dict descriptor with default None

